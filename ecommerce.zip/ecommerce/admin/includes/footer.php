<footer class="main-footer">
    <div class="pull-right hidden-xs">
      
    </div>
    <strong>Developed By &copy; Mai War War Win Shein</strong>
</footer>